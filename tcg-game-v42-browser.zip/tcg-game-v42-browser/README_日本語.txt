BLAZE LEGENDS DX v42 Browser Edition

GitHub Pages向けのブラウザ版です。

フォルダ構成
- index.html : ゲーム本体
- images/set1/ : 第1弾カード画像
- images/set2/ : 第2弾カード画像
- .nojekyll : GitHub Pages用

重要
- フォルダ構成を崩さず、そのままGitHubへ置いてください。
- index.htmlだけをアップロードしてもカード画像は表示されません。
- セーブは公開URLのブラウザlocalStorageに保存されます。
- 旧ローカルHTML版とは保存領域が別なので、旧セーブは自動移行しません。
